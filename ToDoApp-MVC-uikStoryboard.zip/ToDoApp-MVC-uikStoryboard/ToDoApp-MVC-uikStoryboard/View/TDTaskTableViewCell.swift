//
//  TDTaskTableViewCell.swift
//  ToDoApp-MVC-uikStoryboard
//
//  Created by Alan Ulises on 22/08/24.
//

import UIKit

//This class must be always a Cocoa Touch class.
class TDTaskTableViewCell: UITableViewCell {
    // This will connect the layout cell with the text label
    // if an image or another element was in the cell is needed make the reference
    @IBOutlet weak var TDTaskTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
