//
//  TDTaskViewCell.swift
//  ToDoApp-MVC-uik
//
//  Created by Alan Ulises on 17/08/24.
//

import Foundation

import UIKit
class TDTaskViewCell: UITableViewCell {

    @IBOutlet weak var TDTaskTitle: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
