//
//  TDTask.swift
//  ToDoApp-MVC-uik
//
//  Created by Alan Ulises on 17/08/24.
//

import Foundation

struct TDTask {
    var title: String
    var description: String
    var isCompleted: Bool
}
