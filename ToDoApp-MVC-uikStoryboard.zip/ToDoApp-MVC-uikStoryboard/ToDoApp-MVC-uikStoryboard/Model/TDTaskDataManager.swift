//
//  TDTaskDataManager.swift
//  ToDoApp-MVC-uik
//
//  Created by Alan Ulises on 17/08/24.
//

import Foundation


class TDTaskManager{
    private var tdTasks : [TDTask] = []
    var dataTasks = [
        TDTask(title: "Pasear al Perro", description: "Sacar al perro al parque a las 13 horas", isCompleted: false),
        TDTask(title: "Comprar chocolates a mi novia", description: "Le gustan los Ferreo de avellana", isCompleted: true),
        TDTask(title: "Cancelar Spotify Premium", description: "Cancelar antes del día 1 de marzo", isCompleted: false)
    ]
    // Reference for dataTasks variable as a list
    func fetchTDTask(){
        tdTasks = dataTasks
    }
    // This will used for the lenght of the list
    func countTDTask() -> Int {
        tdTasks.count
    }
    // return the value selected by the index [0:2]
    func getTDTask(at index : Int) -> TDTask {
        return tdTasks[index]
    }
    // Prints in the terminal de result of the list
    func updateTDTaskCompletion(index : Int){
            tdTasks[index].isCompleted.toggle()
            print(tdTasks[index].title,tdTasks[index].isCompleted)
        }
}
